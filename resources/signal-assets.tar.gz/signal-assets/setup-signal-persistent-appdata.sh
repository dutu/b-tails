#!/bin/sh

persistence_dir=/live/persistence/TailsData_unlocked
apps_data_dir=/home/amnesia/.var/app

ln -s $persistence_dir/signal $apps_data_dir/org.signal.Signal